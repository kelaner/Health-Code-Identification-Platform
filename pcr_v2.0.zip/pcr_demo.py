import cv2
import glob
import os
import numpy as np
import paddlehub as hub
import matplotlib.pyplot as plt

os.environ["TF_CPP_MIN_LOG_LEVEL"] = '4'
os.environ["CUDA_VISIBLE_DEVICES"] = '0'

# 文字识别
results = hub.Module(name="chinese_ocr_db_crnn_mobile").recognize_text(
    images=[cv2.imread(image_path) for image_path in glob.glob("img_demo/*.jpg")],
    use_gpu=True, output_dir='demo_result',
    visualization=True, box_thresh=0.5, text_thresh=0.5)


# 颜色判断
color_dist = {
    '红码': {'Lower': np.array([0, 60, 60]), 'Upper': np.array([6, 255, 255])},
    '绿码': {'Lower': np.array([35, 43, 35]), 'Upper': np.array([90, 255, 255])},
    '黄码': {'Lower': np.array([26, 43, 46]), 'Upper': np.array([34, 255, 255])},
}


def read_path(file_path):
    for filename in os.listdir(file_path):
        img = cv2.imread(file_path + '/' + filename, 1)

        # 选取区域展示
        # img = img[:, :, [2, 1, 0]]
        # plt.subplot(1, 2, 1)
        # plt.imshow(img)
        # plt.axis('off')
        # plt.subplot(1, 2, 2)
        # plt.imshow(qr)
        # plt.axis('off')
        # plt.show()
        # img = img[:, :, [2, 1, 0]]

        qr = img[400:650, 100:350]
        for i in color_dist.keys():
            k = detect_color(qr, i)
            if k:
                qr_color.append(i)


def detect_color(image, color):
    gs = cv2.GaussianBlur(image, (5, 5), 0)
    hsv = cv2.cvtColor(gs, cv2.COLOR_BGR2HSV)
    erode_hsv = cv2.erode(hsv, None, iterations=2)
    range_hsv = cv2.inRange(erode_hsv, color_dist[color]['Lower'], color_dist[color]['Upper'])
    contours = cv2.findContours(range_hsv.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    if len(contours) > 0:
        return True
    else:
        return False


qr_color = []
read_path("img_demo")


# 表格填充
with open('demo_result.csv', 'w', encoding='utf-8-sig') as f:
    f.write('姓名,检测日期,检测场所,检测结果\n')
    for result in results:
        data = [i['text'] + "," if (
                '@' in i['text']
                or '进场时间' in i['text']
                or '场所名称' in i['text']) else ''
                for i in result['data']]
        date = data.copy()
        for i in date:
            if i == '':
                data.remove(i)
        for i in range(len(data[0])):
            if data[0][i] == '（':
                data[0] = data[0][:i]
                data[0] += ','
                break
        data[1] = data[1][5:15]
        data[1] += ','
        data[2] = data[2][5:]
        k = results.index(result)
        data.append(qr_color[k])
        # print(data)
        f.write(''.join(data) + "\n")
